<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use App\Entity\Message;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;

#[Route('/api', name: 'app_message')]
final class MessageController extends AbstractController
{
    #[Route('/message_save', name: 'app_message')]
     public function saveMessage(Request $request, EntityManagerInterface $em): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Validate the data
        if (!isset($data['message'], $data['username'], $data['room'], $data['timestamp'])) {
            return new JsonResponse(['error' => 'Invalid data'], 400);
        }

        $message = new Message();
        $message->setMessage($data['message']);
        $message->setUsername($data['username']);
        $message->setRoom($data['room']);
        $message->setTimestamp(new \DateTime($data['timestamp']));

        $em->persist($message);
        $em->flush();

        return new JsonResponse(['status' => 'Message saved successfully'], 200);
    }
}
