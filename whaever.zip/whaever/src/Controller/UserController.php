<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use App\Entity\User;

#[Route('/api', name: 'app_user')]
final class UserController extends AbstractController
{
    #[Route('/user', name: 'app_user')]
    public function index(EntityManagerInterface $entityManager): JsonResponse
    {
       $users = $entityManager
            ->getRepository(User::class)
            ->findAll();
    
        $data = [];
    
        foreach ($users as $user) {
           $data[] = [
               'id' => $user->getId(),
               'username' => $user->getUsername(),
               
           ];
        }
    
        return $this->json($data);
    }

     
     #[Route('/me', name: 'app_me')]
     
       public function User(TokenInterface $token): JsonResponse
    {
        // Accessing the current user from the token
        $user = $token->getUser();

        // Returning the user data as JSON (e.g., username)
        return new JsonResponse([
            'username' => $user->getUsername(),
            
            // You can add more user details if needed
        ]);
    }


}
