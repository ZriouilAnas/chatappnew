<?php

namespace App\Controller;

use App\Entity\Convo;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\HttpFoundation\Request;


#[Route('api', name: 'app_convo')]
final class ConvoController extends AbstractController
{
    #[Route('/convo_show', name: 'app_convo')]
    public function index(EntityManagerInterface $entityManager): JsonResponse
    {
       $convos = $entityManager
            ->getRepository(Convo::class)
            ->findAll();
    
        $data = [];
    
        foreach ($convos as $convo) {
           $data[] = [
               'id' => $convo->getId(),
               'name' => $convo->getName(),
               'users_id' => $convo->getUsersId()
               
           ];
        }
    
        return $this->json($data);
    }



#[Route('/convo_create', name: 'convo_create', methods:['POST'])]
public function create(EntityManagerInterface $entityManager, Request $request): JsonResponse
{
    // Get the raw JSON data from the request body
    $data = json_decode($request->getContent(), true);
    
    // Check if 'name' exists in the JSON
    if (!isset($data['name']) || empty(trim($data['name']))) {
        return $this->json(['error' => 'Name is required and cannot be empty'], 400);
    }

    $name = $data['name'];
    $users = $data['users_id'];


    $convo = new convo();
    $convo->setName($name);
    $convo->setUsersId($users);
    
    $entityManager->persist($convo);
    $entityManager->flush();
    
    $data =  [
        'id' => $convo->getId(),
        'name' => $convo->getName(),
        'users_id' => $convo->getUsersId(),
    ];
        
    return $this->json($data, 201);
}

 #[Route('/api/convos', name: 'api_convos', methods: ['GET'])]
    public function oneConvo(EntityManagerInterface $entityManager, Security $security): JsonResponse
    {
        // Get the current user
        $user = $security->getUser();
        
        if (!$user) {
            return new JsonResponse(['error' => 'User not found'], 404);
        }

        // Find all conversations where the current user is a participant
        $conversations = $entityManager->getRepository(Convo::class)
            ->createQueryBuilder('c')
            ->innerJoin('c.users', 'u')
            ->where('u.id = :userId')
            ->setParameter('userId', $user->getId())
            ->getQuery()
            ->getResult();

        // Transform conversations into an array of data
        $data = [];
        foreach ($conversations as $conversation) {
            $data[] = [
                'id' => $conversation->getId(),
                'name' => $conversation->getName(),
                'users' => array_map(fn($user) => $user->getUsername(), $conversation->getUsers()->toArray())
            ];
        }

        // Return the filtered conversations
        return new JsonResponse($data);
    }

}
