<?php

namespace App\Controller;

use App\Entity\Conversation;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;


#[Route('api', name: 'app_conversation')]
class ConversationController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    // Create a conversation and associate users
    #[Route('/conver_create', name: 'create_conversation', methods: ['POST'])]
    public function createConversation(Request $request): JsonResponse
    {
        // Get request data (we expect a JSON payload)
        $data = json_decode($request->getContent(), true);

        $userIds = $data['userIds'] ?? [];
        $name = $data['name'] ?? 'New Conversation';  // Default name

        if (empty($userIds)) {
            return new JsonResponse(['error' => 'User IDs are required'], JsonResponse::HTTP_BAD_REQUEST);
        }

        // Retrieve users from database by their IDs
        $users = $this->entityManager->getRepository(User::class)->findBy(['id' => $userIds]);

        if (count($users) !== count($userIds)) {
            return new JsonResponse(['error' => 'One or more users not found'], JsonResponse::HTTP_NOT_FOUND);
        }

        // Create the conversation entity
        $conversation = new Conversation();
        $conversation->setName($name);
        
        // Add the users to the conversation
        foreach ($users as $user) {
            $conversation->addUser($user); // Assuming you have a method in the Conversation entity to add users
        }

        // Persist the conversation to the database
        $this->entityManager->persist($conversation);
        $this->entityManager->flush();

        
        return new JsonResponse([
            'message' => 'Conversation created successfully',
            'conversation' => [
                'id' => $conversation->getId(),
                'name' => $conversation->getName(),
                'users' => array_map(fn($user) => $user->getUsername(), $users),
            ]
        ], JsonResponse::HTTP_CREATED);
    }

    // Get all conversations for a user
    #[Route('/conver_get', name: 'get_conversations_by_user', methods: ['GET'])]
    public function getConversationsByUser(TokenInterface $token): JsonResponse
    {
        // Find the user by ID
        $user = $token->getUser();

        if (!$user) {
            return new JsonResponse(['error' => 'User not found'], JsonResponse::HTTP_NOT_FOUND);
        }

        // Get the conversations where the user is involved
        $conversations = $user->getConversations(); // Assuming you have a 'getConversations' method in User entity

        $conversationData = [];
        foreach ($conversations as $conversation) {
            $conversationData[] = [
                'id' => $conversation->getId(),
                'name' => $conversation->getName(),
                'users' => array_map(fn($user) => $user->getUsername(), $conversation->getUsers()->toArray())
            ];
        }

        return new JsonResponse($conversationData);
        
    }
}
